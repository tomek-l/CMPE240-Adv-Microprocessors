RITimer example

Example description
This example describes how to use the RIT driver as a periodic interrupt
source. The RIT time interval is configured to 1s. On each RITimer interrupt,
the LED state will toggle.

Special connection requirements
There are no special connection requirements for this example.

Build procedures:
Visit the LPCOpen quickstart guides at link "http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides"
to get started building LPCOpen projects.

